package main
import (
"net/http"
"io"
)
func reqHandler(w http.ResponseWriter, r *http.Request){
io.WriteString(w,"so good to see you once again...")

}
func main(){
http.HandleFunc("/test",reqHandler)
http.ListenAndServe(":30000",nil)
}

