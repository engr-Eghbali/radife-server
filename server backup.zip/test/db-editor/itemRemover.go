package main



import (

	"fmt"

	"os"

	mgo "gopkg.in/mgo.v2"

	"gopkg.in/mgo.v2/bson"



)



func main() {

	//get session

	session, err := mgo.Dial("localhost")

	if err != nil {

		fmt.Printf("dial fail %v\n", err)

		os.Exit(1)

	}

	defer session.Close()



	//error check on every access

	session.SetSafe(&mgo.Safe{})



	//get collection

	coll := session.DB("goods").C("market")



	//remove record

	err = coll.Remove(bson.M{"name":"پنیرپیتزاپروسس مخلوط رنده شده کاله "})

	if err != nil {

		fmt.Printf("remove fail %v\n", err)

		os.Exit(1)

	}

}
