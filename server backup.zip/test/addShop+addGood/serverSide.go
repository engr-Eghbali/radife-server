package main

import (
	"fmt"
	"log"
	"net/http"
	"strconv"

	"github.com/unrolled/secure"
	mgo "gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
)

type Good struct {
	ID      bson.ObjectId `json:"id" bson:"_id,omitempty"`
	Shopid  string        `json:"shopid"`
	Barcode string        `json:"barcode"`
	Name    string        `json:"name"`
	Price   string        `json:"price"`
	Pic     string        `json:"pic"`
	Off     int64         `json:"off"`
	Stock   int64         `json:"stock"`
	Detail  string        `json:"detail"`
	Keyword string        `json:"keyword"`
}

type Shop struct {
	ID       bson.ObjectId `json:"id" bson:"_id,omitempty"`
	Phone    string        `json:"phone"`
	Name     string        `json:"name"`
	Manager  string        `json:"manager"`
	Time     string        `json:"time"`
	Off      int64         `json:"off"`
	Stock    int64         `json:"stock"`
	Star     string        `json:"star"`
	Hood     string        `json:"hood"`
	Add      string        `json:"add"`
	X        string        `json:"x"`
	Y        string        `json:"y"`
	Avatar   string        `json:"avatar"`
	Slide    [3]string     `json:"slide"`
	Detail   string        `json:"detail"`
	Comment  [1]string     `json:"comment"`
	Delivery string        `json:"delivery"`
}

func insertGood(id bson.ObjectId, shopPhone string, barcode string, name string, price string, pic string, off int64, stock int64, detail string, category string, keyword string) (flg bool) {

	session, err := mgo.Dial("127.0.0.1")
	if err != nil {

		log.Print("\n!!!!-- DB connection error:")
		log.Print(err)
		log.Print("\n")
		return false
	} else {

		defer session.Close()
		session.SetMode(mgo.Monotonic, true)
		c := session.DB("goods").C(category)

		err = c.Insert(&Good{ID: id, Shopid: shopPhone, Barcode: barcode, Name: name, Price: price, Pic: pic, Off: off, Stock: stock, Detail: detail, Keyword: keyword})

		if err != nil {

			log.Print(err)
			return false

		} else {
			log.Print("\ngood Inserted:")
			log.Print(id)
			return true
		}
	}
}

func insertShop(id bson.ObjectId, shopPhone string, name string, manager string, time string, off int64, star int64, hood string, add string, x string, y string, avatar string, slide [3]string, detail string, comment [1]string, delivery string, category string) (flg bool) {

	session, err := mgo.Dial("127.0.0.1")
	if err != nil {

		log.Print("\n!!!!-- DB connection error:")
		log.Print(err)
		log.Print("\n")
		return false
	} else {

		defer session.Close()
		session.SetMode(mgo.Monotonic, true)
		c := session.DB("shopinfo").C(category)

		err = c.Insert(&Shop{ID: id, Phone: shopPhone, Name: name, Manager: manager, Time: time, Off: off, Star: strconv.FormatInt(star, 32), Hood: hood, Add: add, X: x, Y: y, Avatar: avatar, Slide: slide, Detail: detail, Comment: comment, Delivery: delivery})

		if err != nil {

			log.Print(err)
			return false

		} else {
			log.Print("\nshop Inserted:")
			log.Print(id)
			return true
		}
	}
}

func addGood_ctrl(w http.ResponseWriter, r *http.Request) {

	w.Header().Set("Content-Type", "text/javascript")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	if r.Method == "POST" {

		r.ParseForm()

		stock, _ := strconv.ParseInt(r.Form["stock"][0], 10, 64)
		id := bson.NewObjectId()
		shophone := r.Form["shopphone"][0]
		barcode := r.Form["barcode"][0]
		name := r.Form["name"][0]
		price := r.Form["price"][0]
		pic := r.Form["pic"][0]
		keyword := r.Form["keyword"][0]

		if pic == "1" {

			pic = "http://migmigfood1.ir/files/goods/" + id.Hex() + ".jpg"
		}

		var off int64 = 0
		detail := r.Form["detail"][0]
		category := r.Form["cat"][0]

		flg := insertGood(id, shophone, barcode, name, price, pic, off, stock, detail, category, keyword)

		if flg {

			fmt.Fprintf(w, id.Hex())
		} else {
			fmt.Fprintf(w, "0")
		}

	}
}

func addShop_ctrl(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/javascript")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	if r.Method == "POST" {

		r.ParseForm()

		id := bson.NewObjectId()
		shopphone := r.Form["shopphone"][0]
		name := r.Form["name"][0]
		manager := r.Form["manager"][0]
		time := r.Form["time"][0]
		off, _ := strconv.ParseInt(r.Form["off"][0], 10, 64)
		star, _ := strconv.ParseInt(r.Form["star"][0], 10, 64)
		hood := r.Form["hood"][0]
		add := r.Form["add"][0]
		x := r.Form["x"][0]
		y := r.Form["y"][0]
		avatar := "http://migmigfood1.ir/files/shops/restaurants/icons/" + shopphone + ".jpg"
		slide1 := "http://migmigfood1.ir/files/shops/resturants/slides/" + shopphone + "-1.jpg"
		slide2 := "http://migmigfood1.ir/files/shops/resturants/slides/" + shopphone + "-2.jpg"
		slide3 := "http://migmigfood1.ir/files/shops/resturants/slides/" + shopphone + "-3.jpg"
		slides := [3]string{slide1, slide2, slide3}
		detail := r.Form["detail"][0]
		comment := [1]string{name + "@we are at your service"}
		delivery := "100"
		category := r.Form["cat"][0]

		flg := insertShop(id, shopphone, name, manager, time, off, star, hood, add, x, y, avatar, slides, detail, comment, delivery, category)

		if flg {

			fmt.Fprintf(w, id.Hex())
		} else {
			fmt.Fprintf(w, "0")
		}

	}
}

func main() {

	addGood_rout := secure.New(secure.Options{
		AllowedHosts:            []string{"ssl.example.com"},                     // AllowedHosts is a list of fully qualified domain names that are allowed. Default is empty list, which allows any and all host names.
		HostsProxyHeaders:       []string{"X-Forwarded-Hosts"},                   // HostsProxyHeaders is a set of header keys that may hold a proxied hostname value for the request.
		SSLRedirect:             true,                                            // If SSLRedirect is set to true, then only allow HTTPS requests. Default is false.
		SSLTemporaryRedirect:    false,                                           // If SSLTemporaryRedirect is true, the a 302 will be used while redirecting. Default is false (301).
		SSLHost:                 "ssl.example.com",                               // SSLHost is the host name that is used to redirect HTTP requests to HTTPS. Default is "", which indicates to use the same host.
		SSLProxyHeaders:         map[string]string{"X-Forwarded-Proto": "https"}, // SSLProxyHeaders is set of header keys with associated values that would indicate a valid HTTPS request. Useful when using Nginx: `map[string]string{"X-Forwarded-Proto": "https"}`. Default is blank map.
		STSSeconds:              315360000,                                       // STSSeconds is the max-age of the Strict-Transport-Security header. Default is 0, which would NOT include the header.
		STSIncludeSubdomains:    true,                                            // If STSIncludeSubdomains is set to true, the `includeSubdomains` will be appended to the Strict-Transport-Security header. Default is false.
		STSPreload:              true,                                            // If STSPreload is set to true, the `preload` flag will be appended to the Strict-Transport-Security header. Default is false.
		ForceSTSHeader:          false,                                           // STS header is only included when the connection is HTTPS. If you want to force it to always be added, set to true. `IsDevelopment` still overrides this. Default is false.
		FrameDeny:               true,                                            // If FrameDeny is set to true, adds the X-Frame-Options header with the value of `DENY`. Default is false.
		CustomFrameOptionsValue: "SAMEORIGIN",                                    // CustomFrameOptionsValue allows the X-Frame-Options header value to be set with a custom value. This overrides the FrameDeny option. Default is "".
		ContentTypeNosniff:      true,                                            // If ContentTypeNosniff is true, adds the X-Content-Type-Options header with the value `nosniff`. Default is false.
		BrowserXssFilter:        true,                                            // If BrowserXssFilter is true, adds the X-XSS-Protection header with the value `1; mode=block`. Default is false.
		CustomBrowserXssValue:   "1; report=https://example.com/xss-report",      // CustomBrowserXssValue allows the X-XSS-Protection header value to be set with a custom value. This overrides the BrowserXssFilter option. Default is "".
		ContentSecurityPolicy:   "default-src 'self'",                            // ContentSecurityPolicy allows the Content-Security-Policy header value to be set with a custom value. Default is "".
		// PublicKey: `pin-sha256="base64+primary=="; pin-sha256="base64+backup=="; max-age=5184000; includeSubdomains; report-uri="https://www.example.com/hpkp-report"`, // PublicKey implements HPKP to prevent MITM attacks with forged certificates. Default is "".
		//ReferrerPolicy: "same-origin" // ReferrerPolicy allows the Referrer-Policy header with the value to be set with a custom value. Default is "".
		//***triger***
		IsDevelopment: true, // This will cause the AllowedHosts, SSLRedirect, and STSSeconds/STSIncludeSubdomains options to be ignored during development. When deploying to production, be sure to set this to false.
	})

	addShop_rout := secure.New(secure.Options{
		AllowedHosts:            []string{"ssl.example.com"},                     // AllowedHosts is a list of fully qualified domain names that are allowed. Default is empty list, which allows any and all host names.
		HostsProxyHeaders:       []string{"X-Forwarded-Hosts"},                   // HostsProxyHeaders is a set of header keys that may hold a proxied hostname value for the request.
		SSLRedirect:             true,                                            // If SSLRedirect is set to true, then only allow HTTPS requests. Default is false.
		SSLTemporaryRedirect:    false,                                           // If SSLTemporaryRedirect is true, the a 302 will be used while redirecting. Default is false (301).
		SSLHost:                 "ssl.example.com",                               // SSLHost is the host name that is used to redirect HTTP requests to HTTPS. Default is "", which indicates to use the same host.
		SSLProxyHeaders:         map[string]string{"X-Forwarded-Proto": "https"}, // SSLProxyHeaders is set of header keys with associated values that would indicate a valid HTTPS request. Useful when using Nginx: `map[string]string{"X-Forwarded-Proto": "https"}`. Default is blank map.
		STSSeconds:              315360000,                                       // STSSeconds is the max-age of the Strict-Transport-Security header. Default is 0, which would NOT include the header.
		STSIncludeSubdomains:    true,                                            // If STSIncludeSubdomains is set to true, the `includeSubdomains` will be appended to the Strict-Transport-Security header. Default is false.
		STSPreload:              true,                                            // If STSPreload is set to true, the `preload` flag will be appended to the Strict-Transport-Security header. Default is false.
		ForceSTSHeader:          false,                                           // STS header is only included when the connection is HTTPS. If you want to force it to always be added, set to true. `IsDevelopment` still overrides this. Default is false.
		FrameDeny:               true,                                            // If FrameDeny is set to true, adds the X-Frame-Options header with the value of `DENY`. Default is false.
		CustomFrameOptionsValue: "SAMEORIGIN",                                    // CustomFrameOptionsValue allows the X-Frame-Options header value to be set with a custom value. This overrides the FrameDeny option. Default is "".
		ContentTypeNosniff:      true,                                            // If ContentTypeNosniff is true, adds the X-Content-Type-Options header with the value `nosniff`. Default is false.
		BrowserXssFilter:        true,                                            // If BrowserXssFilter is true, adds the X-XSS-Protection header with the value `1; mode=block`. Default is false.
		CustomBrowserXssValue:   "1; report=https://example.com/xss-report",      // CustomBrowserXssValue allows the X-XSS-Protection header value to be set with a custom value. This overrides the BrowserXssFilter option. Default is "".
		ContentSecurityPolicy:   "default-src 'self'",                            // ContentSecurityPolicy allows the Content-Security-Policy header value to be set with a custom value. Default is "".
		// PublicKey: `pin-sha256="base64+primary=="; pin-sha256="base64+backup=="; max-age=5184000; includeSubdomains; report-uri="https://www.example.com/hpkp-report"`, // PublicKey implements HPKP to prevent MITM attacks with forged certificates. Default is "".
		//ReferrerPolicy: "same-origin" // ReferrerPolicy allows the Referrer-Policy header with the value to be set with a custom value. Default is "".
		//***triger***
		IsDevelopment: true, // This will cause the AllowedHosts, SSLRedirect, and STSSeconds/STSIncludeSubdomains options to be ignored during development. When deploying to production, be sure to set this to false.
	})

	app1 := addGood_rout.Handler(http.HandlerFunc(addGood_ctrl))
	app2 := addShop_rout.Handler(http.HandlerFunc(addShop_ctrl))

	http.Handle("/addGood", app1)
	http.Handle("/addShop", app2)
	log.Fatal(http.ListenAndServe(":3035", nil))
}

